//package com.example.uijp.gulaDarah.dataModel
//
//import androidx.room.Entity
//import androidx.room.PrimaryKey
//
//@Entity(tableName = "gula_darah")
//data class GulaDarah(
//    @PrimaryKey(autoGenerate = true) val id: Int = 0,
//    val date: String,
//    val time: String,
//    val level: Int
//)
