package com.example.uijp.laporan

class GulaHarian (
    val hari: String,
    val totalGula: String,
    val status: String
    )